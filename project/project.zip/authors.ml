let hours_worked = 40
