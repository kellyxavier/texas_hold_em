let hours_worked = 15
